# Novidades

Uma seção `## versão` por versão, a mais nova em cima, com um item por linha começando em `- `.
O texto aparece na tela "Novidades" depois da atualização e na janela de atualização.

## 0.1.0
- Primeira versão instalada: Pacientes, Agenda, Financeiro, Prontuário, Documentos e Procedimentos.
- O app passa a se atualizar sozinho: avisa quando há versão nova e instala ao fechar.
