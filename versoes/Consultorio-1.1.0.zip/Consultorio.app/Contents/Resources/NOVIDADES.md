# Novidades

Uma seção `## versão` por versão, a mais nova em cima, com um item por linha começando em `- `.
O texto aparece na tela "Novidades" depois da atualização e na janela de atualização.

## 1.1.0
- Tela nova do atendimento: painel fixo com abas, formatação ao selecionar o texto e sinais vitais mais compactos.
- Escriba: com o consentimento do paciente, o app ouve a consulta, presencial ou teleconsulta, e redige o SOAP. "Iniciar atendimento" já liga a escuta, e um só "Pausar" para tudo.
- Na teleconsulta, use fone: com a caixa de som, a voz do paciente pode aparecer duas vezes na transcrição.
- No rascunho do SOAP, "Usar o que falta" completa só o que você ainda não escreveu, e os sinais vitais citados são conferidos com os digitados.
- Em Ajustes → IA, "Como eu escrevo o SOAP" ensina o seu jeito de escrever ao escriba.
- Resumo do histórico do paciente pela IA, no atendimento, na ficha e na agenda, com "Preparar o dia".
- Documentos no papel com o seu estilo e o código TUSS no pedido de exames; textos e favoritos editáveis em Ajustes.
- Editor de documentos mais limpo; os documentos preparados ficam no painel do atendimento e são emitidos ao finalizar.
- "Assinar no Adobe" abre o PDF direto no Adobe, sem arrastar.
- Se faltar o backup antes de uma atualização, dá para configurá-lo ali mesmo.

## 1.0.0
- Início do uso de verdade do Consultório. O conteúdo é o mesmo da 0.1.1.

## 0.1.1
- A linha do tempo da ficha ficou mais limpa: cada atendimento é uma linha, e clicar na data abre o prontuário.
- Agora há dois endereços em Ajustes → Profissional: o da receita (cabeçalho dos documentos) e o do atendimento (mensagens de confirmação).
- A faixa "Modo de revisão" aparece inteira na ficha do paciente.

## 0.1.0
- Primeira versão instalada: Pacientes, Agenda, Financeiro, Prontuário, Documentos e Procedimentos.
- O app passa a se atualizar sozinho: avisa quando há versão nova e instala ao fechar.
