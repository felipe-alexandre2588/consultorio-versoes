# Novidades

Uma seção `## versão` por versão, a mais nova em cima, com um item por linha começando em `- `.
O texto aparece na tela "Novidades" depois da atualização e na janela de atualização.

## 0.1.1
- A linha do tempo da ficha ficou mais limpa: cada atendimento é uma linha, e clicar na data abre o prontuário.
- Agora há dois endereços em Ajustes → Profissional: o da receita (cabeçalho dos documentos) e o do atendimento (mensagens de confirmação).
- A faixa "Modo de revisão" aparece inteira na ficha do paciente.

## 0.1.0
- Primeira versão instalada: Pacientes, Agenda, Financeiro, Prontuário, Documentos e Procedimentos.
- O app passa a se atualizar sozinho: avisa quando há versão nova e instala ao fechar.
